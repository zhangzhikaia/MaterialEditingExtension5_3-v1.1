// Copyright lurongjiu. All Rights Reserved.Intended year of publication: 2023.

#include "MaterialEditingExtensionBPLibrary.h"
#include "MaterialEditingExtension.h"
#include "Materials/MaterialExpressionCustom.h"
#include "Materials/Material.h"
#include "MaterialShared.h"
#include "MaterialDomain.h"
#include "Engine/EngineTypes.h"
#include "MaterialExpressionIO.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(MaterialEditingExtensionBPLibrary)

static int32 GetExpressionOutputIndexByName(UMaterialExpression* Expression, const FName OutputName)
{
	check(Expression);

	int32 Result = INDEX_NONE;

	if (Expression->Outputs.Num() == 0)
	{
		// leave as INDEX_NONE
	}
	// Return first output if no name specified
	else if (OutputName.IsNone())
	{
		Result = 0;
	}
	else
	{
		// Iterate over outputs and look for name match
		for (int OutIdx = 0; OutIdx < Expression->Outputs.Num(); OutIdx++)
		{
			bool bFoundMatch = false;

			FExpressionOutput& Output = Expression->Outputs[OutIdx];
			// If output name is no empty - see if it matches
			if (!Output.OutputName.IsNone())
			{
				if (OutputName == Output.OutputName)
				{
					bFoundMatch = true;
				}
			}
			// if it is empty we look for R/G/B/A
			else
			{
				if (Output.MaskR && !Output.MaskG && !Output.MaskB && !Output.MaskA && OutputName == TEXT("R"))
				{
					bFoundMatch = true;
				}
				else if (!Output.MaskR && Output.MaskG && !Output.MaskB && !Output.MaskA && OutputName == TEXT("G"))
				{
					bFoundMatch = true;
				}
				else if (!Output.MaskR && !Output.MaskG && Output.MaskB && !Output.MaskA && OutputName == TEXT("B"))
				{
					bFoundMatch = true;
				}
				else if (!Output.MaskR && !Output.MaskG && !Output.MaskB && Output.MaskA && OutputName == TEXT("A"))
				{
					bFoundMatch = true;
				}
			}

			// Got a match, remember the index, exit iteration
			if (bFoundMatch)
			{
				Result = OutIdx;
				break;
			}
		}
	}

	return Result;
}

UMaterialEditingExtensionBPLibrary::UMaterialEditingExtensionBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

float UMaterialEditingExtensionBPLibrary::MaterialEditingExtensionSampleFunction(float Param)
{
	return -1;
}

#if WITH_EDITOR

bool UMaterialEditingExtensionBPLibrary::GetMaterialUseAttribute(const UMaterial* Material)
{
	if (Material)
	{
		return Material->bUseMaterialAttributes;
	}
	else
	{
		return false;
	}
}

void UMaterialEditingExtensionBPLibrary::SetMaterialUseAttribute(UMaterial* Material, bool UseAttribute)
{
	if (Material)
	{
		Material->bUseMaterialAttributes = UseAttribute;
	}
}

bool UMaterialEditingExtensionBPLibrary::GetMaterialTwoSided(const UMaterial* Material)
{
	if (Material)
	{
		return Material->TwoSided;
	}
	else
	{
		return false;
	}
}

void UMaterialEditingExtensionBPLibrary::SetMaterialTwoSided(UMaterial* Material, bool TwoSided)
{
	if (Material)
	{
		Material->TwoSided = TwoSided;
	}
}

bool UMaterialEditingExtensionBPLibrary::GetMaterialCastRayTracedShadows(const UMaterial* Material)
{
	if (Material)
	{
		return Material->bCastRayTracedShadows;
	}
	else
	{
		return false;
	}
}

void UMaterialEditingExtensionBPLibrary::SetMaterialCastRayTracedShadows(UMaterial* Material, bool CastRayTracedShadows)
{
	if (Material)
	{
		Material->bCastRayTracedShadows = CastRayTracedShadows;
	}
}

bool UMaterialEditingExtensionBPLibrary::ConnectMaterialPropertyPlus(UMaterialExpression* FromExpression, FString FromOutputName, EMaterialPropertySeek MaterialPropertySeek)
{
	bool bResult = false;
	if (FromExpression)
	{
		// Get material that owns this expression
		UMaterial* Material = Cast<UMaterial>(FromExpression->GetOuter());
		if (Material)
		{
			FExpressionInput* Input = nullptr;
			switch (MaterialPropertySeek)
			{
			case EMaterialPropertySeek::MPS_WorldPositionOffset:
			{
				Input = Material->GetExpressionInputForProperty(EMaterialProperty::MP_WorldPositionOffset);
				break;
			}
			case EMaterialPropertySeek::MPS_PixelDepthOffset:
			{
				Input = Material->GetExpressionInputForProperty(EMaterialProperty::MP_PixelDepthOffset);
				break;
			}
			case EMaterialPropertySeek::MPS_MaterialAttributes:
			{
				Input = Material->GetExpressionInputForProperty(EMaterialProperty::MP_MaterialAttributes);
				break;
			}
			}
			int32 FromIndex = GetExpressionOutputIndexByName(FromExpression, *FromOutputName);
			if (Input && FromIndex != INDEX_NONE)
			{
				Input->Connect(FromIndex, FromExpression);
				bResult = true;
			}
		}
	}
	return bResult;
}

void UMaterialEditingExtensionBPLibrary::SetMaterialDomain(UMaterial* Material, EMaterialDomain MaterialDomainSet)
{
	if (Material)
	{
		*Material->GetClass()->FindPropertyByName("MaterialDomain")->ContainerPtrToValuePtr<EMaterialDomain>(Material) = MaterialDomainSet;
	}
}
void UMaterialEditingExtensionBPLibrary::SetMaterialBlendMode(UMaterial* Material, EBlendMode MaterialBlendModeSet)
{
	if (Material)
	{
		*Material->GetClass()->FindPropertyByName("BlendMode")->ContainerPtrToValuePtr<EBlendMode>(Material) = MaterialBlendModeSet;
	}
}
void UMaterialEditingExtensionBPLibrary::SetMaterialShadingModel(UMaterial* Material, EMaterialShadingModel MaterialShadingModelSet)
{
	if (Material)
	{
		*Material->GetClass()->FindPropertyByName("ShadingModel")->ContainerPtrToValuePtr<EMaterialShadingModel>(Material) = MaterialShadingModelSet;
	}
}

UMaterialExpressionCustom* UMaterialEditingExtensionBPLibrary::GetCustomByDescription(UMaterial* Material, FString DescriptionCheck)
{
	if (Material)
	{
		for (UMaterialExpression* MaterialExpression : Material->GetExpressions())
		{
			if (UMaterialExpressionCustom* Custom = Cast<UMaterialExpressionCustom>(MaterialExpression))
			{
				if (*Custom->GetClass()->FindPropertyByName("Description")->ContainerPtrToValuePtr<FString>(Custom) == DescriptionCheck)
				{
					return Custom;
				}
			}
		}

	}
	return nullptr;
}

FString UMaterialEditingExtensionBPLibrary::GetCustomCode(UMaterialExpressionCustom* ExpressionCustom)
{
	if (ExpressionCustom)
	{
		return *ExpressionCustom->GetClass()->FindPropertyByName("Code")->ContainerPtrToValuePtr<FString>(ExpressionCustom);
	}
	else
	{
		return "null";
	}
}

void UMaterialEditingExtensionBPLibrary::SetCustomCode(UMaterialExpressionCustom* ExpressionCustom, FString CodeSet)
{
	if (ExpressionCustom)
	{
		*ExpressionCustom->GetClass()->FindPropertyByName("Code")->ContainerPtrToValuePtr<FString>(ExpressionCustom) = CodeSet;
	}
}
#endif